using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace IdleScreenService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private System.Threading.Timer? _idleCheckTimer;

        // Fixed folder name spelling
        private const string ScreenSaverFolder = @"C:\ScreenSavers";
        private readonly List<string> _screensavers = new();
        private int _currentIndex = 0;
        private Process? _currentProcess;
        private bool _isRunningScreensaver = false;

        // state saved to restore after screensaver stops
        private readonly Dictionary<int, ProcessPriorityClass> _originalPriorities = new();
        private string? _previousPowerSchemeGuid;
        private int? _previousAppsUseLightTheme;
        private int? _previousSystemUsesLightTheme;

        private const int IdleThresholdMinutes = 1;
        private const int ScreensaverDurationMinutes = 1;

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Service started�");

            LoadScreensavers();

            // Check idle every second
            _idleCheckTimer = new System.Threading.Timer(CheckIdle, null, TimeSpan.Zero, TimeSpan.FromSeconds(1));

            return Task.CompletedTask;
        }

        private void LoadScreensavers()
        {
            _screensavers.Clear();

            if (Directory.Exists(ScreenSaverFolder))
            {
                foreach (var file in Directory.GetFiles(ScreenSaverFolder, "*.scr"))
                {
                    string name = Path.GetFileName(file);
                    if (name.Equals("Pipes.scr", StringComparison.OrdinalIgnoreCase) ||
                        name.Equals("Maze.scr", StringComparison.OrdinalIgnoreCase) ||
                        name.Equals("Lattice.scr", StringComparison.OrdinalIgnoreCase))
                    {
                        _screensavers.Add(file);
                        _logger.LogInformation($"Found screensaver: {file}");
                    }
                }
            }
            else
            {
                _logger.LogWarning($"Screensaver folder not found: {ScreenSaverFolder}. Falling back to bundled screensavers.");

                // Fallback: look for the .scr files next to the application's executable (project files copied to output)
                string baseDir = AppContext.BaseDirectory;
                string[] bundled = new[] { "Pipes.scr", "Maze.scr", "Lattice.scr" };

                foreach (var name in bundled)
                {
                    string p = Path.Combine(baseDir, name);
                    if (File.Exists(p))
                    {
                        _screensavers.Add(p);
                        _logger.LogInformation($"Found bundled screensaver: {p}");
                    }
                    else
                    {
                        _logger.LogDebug($"Bundled screensaver not found in output: {p}");
                    }
                }
            }

            if (_screensavers.Count == 0)
            {
                _logger.LogWarning("No valid .scr files found.");
            }
        }

        private void CheckIdle(object? state)
        {
            uint idleMs = NativeMethods.GetIdleTime();
            TimeSpan idle = TimeSpan.FromMilliseconds(idleMs);

            // Not running a screensaver yet
            if (!_isRunningScreensaver)
            {
                if (idle.TotalMinutes >= IdleThresholdMinutes && _screensavers.Count > 0)
                {
                    _logger.LogInformation("Idle threshold reached � starting screensavers�");
                    StartNextScreensaver();
                }
            }
            else
            {
                // If user moves/clicks, stop everything
                if (idle.TotalSeconds < 1)
                {
                    _logger.LogInformation("User returned � stopping screensaver.");
                    StopScreensaver();
                }
            }
        }

        private void StartNextScreensaver()
        {
            if (_screensavers.Count == 0)
                return;

            _isRunningScreensaver = true;

            string nextScr = _screensavers[_currentIndex % _screensavers.Count];
            _currentIndex++;

            _logger.LogInformation($"Starting: {nextScr}");

            // Apply system-wide optimizations for low power / reduced activity
            try
            {
                ApplyPowerSaverAndDarkMode();
                ThrottleOtherProcesses();
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"Failed to apply power-saving adjustments: {ex.Message}");
            }

            _currentProcess = new Process
            {
                StartInfo = new ProcessStartInfo(nextScr)
                {
                    UseShellExecute = true
                }
            };

            try
            {
                _currentProcess.Start();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to start screensaver {nextScr}: {ex.Message}");
                _isRunningScreensaver = false;
                _currentProcess = null;
                // attempt to restore adjustments
                try { RestorePowerSchemeAndTheme(); RestoreProcessPriorities(); } catch { }
                return;
            }

            // Timer to move to next screensaver after set duration
            _ = Task.Delay(TimeSpan.FromMinutes(ScreensaverDurationMinutes)).ContinueWith(t =>
            {
                if (_isRunningScreensaver)
                {
                    StopScreensaver();
                    StartNextScreensaver();
                }
            });
        }

        private void StopScreensaver()
        {
            try
            {
                if (_currentProcess != null && !_currentProcess.HasExited)
                {
                    _currentProcess.Kill(true);
                    _currentProcess.WaitForExit(2000);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error stopping screensaver: {ex.Message}");
            }
            finally
            {
                _currentProcess = null;
                _isRunningScreensaver = false;

                // Restore system state
                try
                {
                    RestoreProcessPriorities();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning($"Failed to restore process priorities: {ex.Message}");
                }

                try
                {
                    RestorePowerSchemeAndTheme();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning($"Failed to restore power scheme or theme: {ex.Message}");
                }
            }
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Service stopping�");
            _idleCheckTimer?.Change(Timeout.Infinite, Timeout.Infinite);
            _idleCheckTimer?.Dispose();
            StopScreensaver();
            return base.StopAsync(cancellationToken);
        }

        #region Power and process adjustments

        private void ThrottleOtherProcesses()
        {
            _originalPriorities.Clear();

            int currentSession = Process.GetCurrentProcess().SessionId;
            int thisPid = Process.GetCurrentProcess().Id;
            int? screensaverPid = null;
            try { screensaverPid = _currentProcess?.Id; } catch { }

            foreach (var proc in Process.GetProcesses())
            {
                try
                {
                    if (proc.Id == thisPid) continue;
                    if (screensaverPid.HasValue && proc.Id == screensaverPid.Value) continue;

                    // Skip system/session 0 processes
                    if (proc.SessionId == 0) continue;

                    // Only affect processes in same session (interactive user's apps)
                    if (proc.SessionId != currentSession) continue;

                    // Save original priority then set to Idle if possible
                    try
                    {
                        var orig = proc.PriorityClass;
                        _originalPriorities[proc.Id] = orig;
                        proc.PriorityClass = ProcessPriorityClass.Idle;
                    }
                    catch
                    {
                        // ignore processes we can't touch
                    }
                }
                catch
                {
                    // ignore processes that exit or deny access
                }
            }

            _logger.LogInformation($"Throttled {_originalPriorities.Count} processes.");
        }

        private void RestoreProcessPriorities()
        {
            foreach (var kv in _originalPriorities)
            {
                try
                {
                    var pid = kv.Key;
                    var priority = kv.Value;
                    var proc = Process.GetProcessById(pid);
                    try { proc.PriorityClass = priority; }
                    catch { }
                }
                catch
                {
                    // process gone
                }
            }

            _originalPriorities.Clear();
            _logger.LogInformation("Restored process priorities.");
        }

        private void ApplyPowerSaverAndDarkMode()
        {
            // Save current active power scheme
            try
            {
                _previousPowerSchemeGuid = GetActivePowerSchemeGuid();
            }
            catch (Exception ex)
            {
                _logger.LogDebug($"Could not read active power scheme: {ex.Message}");
            }

            // Set to Power Saver plan GUID - may require privileges
            const string powerSaverGuid = "a1841308-3541-4fab-bc81-f71556f20b4a";
            try
            {
                RunPowerCfg($"/setactive {powerSaverGuid}");
                _logger.LogInformation("Set power scheme to Power Saver.");
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"Failed to set power scheme: {ex.Message}");
            }

            // Set Dark Mode for apps and system (HKCU)
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize");
                if (key != null)
                {
                    _previousAppsUseLightTheme = key.GetValue("AppsUseLightTheme") as int? ?? (int?)(key.GetValue("AppsUseLightTheme") as object as int?);
                    _previousSystemUsesLightTheme = key.GetValue("SystemUsesLightTheme") as int? ?? (int?)(key.GetValue("SystemUsesLightTheme") as object as int?);

                    try { key.SetValue("AppsUseLightTheme", 0, RegistryValueKind.DWord); } catch { }
                    try { key.SetValue("SystemUsesLightTheme", 0, RegistryValueKind.DWord); } catch { }

                    BroadcastThemeChange();
                    _logger.LogInformation("Attempted to enable Dark Mode (HKCU updated).");
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"Failed to set dark mode: {ex.Message}");
            }
        }

        private void RestorePowerSchemeAndTheme()
        {
            // Restore power scheme
            if (!string.IsNullOrEmpty(_previousPowerSchemeGuid))
            {
                try
                {
                    RunPowerCfg($"/setactive {_previousPowerSchemeGuid}");
                    _logger.LogInformation("Restored previous power scheme.");
                }
                catch (Exception ex)
                {
                    _logger.LogWarning($"Failed to restore power scheme: {ex.Message}");
                }
            }

            // Restore theme values
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize");
                if (key != null)
                {
                    if (_previousAppsUseLightTheme.HasValue)
                        try { key.SetValue("AppsUseLightTheme", _previousAppsUseLightTheme.Value, RegistryValueKind.DWord); } catch { }

                    if (_previousSystemUsesLightTheme.HasValue)
                        try { key.SetValue("SystemUsesLightTheme", _previousSystemUsesLightTheme.Value, RegistryValueKind.DWord); } catch { }

                    BroadcastThemeChange();
                    _logger.LogInformation("Restored theme settings.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"Failed to restore theme: {ex.Message}");
            }
        }

        private static void BroadcastThemeChange()
        {
            try
            {
                const int HWND_BROADCAST = 0xffff;
                const uint WM_SETTINGCHANGE = 0x001A;
                SendMessageTimeout(new IntPtr(HWND_BROADCAST), WM_SETTINGCHANGE, UIntPtr.Zero, "", SendMessageTimeoutFlags.SMTO_ABORTIFHUNG, 100, out _);
            }
            catch
            {
                // ignore
            }
        }

        private static string? GetActivePowerSchemeGuid()
        {
            try
            {
                var (output, _) = RunPowerCfgCaptureOutput("/GETACTIVESCHEME");
                // output contains something like: "Power Scheme GUID: xxxx-...  (scheme name)"
                foreach (var line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var idx = line.IndexOf("GUID:", StringComparison.OrdinalIgnoreCase);
                    if (idx >= 0)
                    {
                        var part = line.Substring(idx + 5).Trim();
                        var guid = part.Split(' ')[0].Trim();
                        return guid;
                    }
                }
            }
            catch
            {
            }

            return null;
        }

        private static void RunPowerCfg(string args)
        {
            var psi = new ProcessStartInfo("powercfg", args)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using var p = Process.Start(psi);
            p?.WaitForExit(5000);
            if (p != null && p.ExitCode != 0)
            {
                throw new InvalidOperationException($"powercfg exited with {p.ExitCode}");
            }
        }

        private static (string output, int exitCode) RunPowerCfgCaptureOutput(string args)
        {
            var psi = new ProcessStartInfo("powercfg", args)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            using var p = Process.Start(psi);
            if (p == null)
                return (string.Empty, -1);

            string output = p.StandardOutput.ReadToEnd();
            p.WaitForExit(5000);
            return (output, p.ExitCode);
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, SendMessageTimeoutFlags fuFlags, uint uTimeout, out UIntPtr lpdwResult);

        [Flags]
        private enum SendMessageTimeoutFlags : uint
        {
            SMTO_NORMAL = 0x0,
            SMTO_BLOCK = 0x1,
            SMTO_ABORTIFHUNG = 0x2,
            SMTO_NOTIMEOUTIFNOTHUNG = 0x8
        }

        #endregion
    }

    internal static class NativeMethods
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        [DllImport("user32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        public static uint GetIdleTime()
        {
            LASTINPUTINFO info = new()
            {
                cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO))
            };

            if (!GetLastInputInfo(ref info))
                return 0;

            return (uint)Environment.TickCount - info.dwTime;
        }
    }
}