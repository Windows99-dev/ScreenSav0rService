using System;
using System.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Hosting.WindowsServices; // Add this using directive

namespace IdleScreenService
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            bool isService = !(Environment.UserInteractive) && !Debugger.IsAttached;

            var builder = Host.CreateDefaultBuilder(args)
                .ConfigureServices((context, services) =>
                {
                    services.AddHostedService<Worker>();
                });

            // When running as a Windows Service, enable UseWindowsService().
            if (isService)
            {
                builder.UseWindowsService();
            }
            else
            {
                // Console / interactive mode
                builder.UseConsoleLifetime();
            }

            var host = builder.Build();
            host.Run();
        }
    }
}
